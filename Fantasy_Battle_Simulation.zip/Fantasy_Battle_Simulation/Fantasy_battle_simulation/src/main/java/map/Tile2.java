package map;

import java.awt.image.BufferedImage;

/**
 * used in generating map in GUI
 */
public class Tile2 {
    public BufferedImage image;
}
