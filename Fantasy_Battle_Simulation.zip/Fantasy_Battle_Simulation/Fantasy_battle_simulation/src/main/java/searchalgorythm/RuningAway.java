package searchalgorythm;

import map.MAPtable;
import map.Tile;
import characters.Character;
import java.util.ArrayList;

/*
public class RunningAway{
    public ArrayList<> runAway(Character character, Character target){
        ArrayList<Tile> tiles = new ArrayList<>();
        boolean goalReached = false;
        int range = character.getMovement();
        while (goalReached = true){
            if()
        }

    }
}
*/
