package simulation;

import gui.GamePanel;

import javax.swing.*;
public class SimulationGamePanel extends JPanel {
    private GamePanel simulationGamePanel;
}